CREATE PROCEDURE `insert_ceshi`(`i` INT(11))
  BEGIN
	label1 :
LOOP

SET i = i + 1 ; INSERT INTO ceshi
VALUES
	(NULL, concat('标题', i)) ;
IF i < 500 THEN
	ITERATE label1 ;
END
IF ; LEAVE label1 ;
END
LOOP
	label1 ;
SET @x = i ;
END