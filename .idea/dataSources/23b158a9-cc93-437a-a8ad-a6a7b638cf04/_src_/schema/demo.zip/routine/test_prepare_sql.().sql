CREATE PROCEDURE `test_prepare_sql`()
  BEGIN
	prepare stmt from 'insert into ceshi values (null, ?)';
	set @a = 0;
	label1:loop
	set @a = @a + 1;
	EXECUTE stmt using @a;
	if @a < 400 then ITERATE label1;
	end if;
	leave label1;
	end loop label1;
end